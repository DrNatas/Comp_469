"""COMP 469 - Chapter 2: Intelligent Agents
Pac-Man agent program. INSTRUCTOR REFERENCE SOLUTION.

This is a complete implementation of every TODO(CH2-...) item in the
student starter. It is written the way a strong submission should look:
the percept declares exactly what is sensed, preferences are named, memory
is a compact summary of the percept sequence, and scoring is separated from
selection so every decision can be explained.

Agent type: model-based, utility-based (AIMA 4e Figures 2.12 and 2.14).

  Sensors        -> Percept, built by the environment from declared fields
  Internal state -> visit_counts, position_history
  Utility        -> UtilityWeights, applied in evaluate_action
  Actuators      -> the single action returned by choose_action

The performance measure lives in pacman/rules.py and is NOT this utility
function. The two are deliberately different: the agent maximises what it
can compute locally, and the environment judges the result.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass

from pacman.maze import DIRECTION_NAMES, MazeModel

AGENT_NAME = "student"


@dataclass(frozen=True)
class Percept:
    """Everything the agent senses on this turn. Nothing else is available."""

    player: tuple[int, int]
    current_direction: tuple[int, int]
    pellets: frozenset[tuple[int, int]]
    power_pellets: frozenset[tuple[int, int]]
    released_ghosts: tuple[tuple[int, int], ...]
    legal_actions: tuple[tuple[int, int], ...]
    frightened_time_remaining: float

    @property
    def frightened(self) -> bool:
        return self.frightened_time_remaining > 0.0


@dataclass(frozen=True)
class UtilityWeights:
    """Named preferences. This is the agent's utility function, not the
    environment's performance measure."""

    # Food. The distance term is the engine that keeps the agent moving
    # toward work; the landing bonuses break ties in favour of eating now.
    food_distance: float = -2.0
    regular_pellet: float = 25.0
    power_pellet: float = 80.0

    # Ghosts while frightened. A negative distance coefficient makes a
    # closer frightened ghost more attractive, which is the inverse of the
    # danger case below.
    frightened_ghost_capture: float = 200.0
    frightened_ghost_distance: float = -1.0

    # Ghosts while dangerous. The step penalties are graded rather than
    # binary so the agent leaves itself an escape route instead of only
    # reacting on the last tile.
    collision: float = -1000.0
    ghost_one_step: float = -800.0
    ghost_two_steps: float = -400.0
    ghost_three_steps: float = -150.0
    safe_ghost_distance: float = 1.0
    safe_ghost_distance_cap: int = 8

    # Movement shape. Continuation is a mild tie-break that stops the
    # agent from jittering at junctions when two options score equally.
    continuation: float = 1.0

    # Memory terms. These are what the simple reflex agent cannot express,
    # and they are the reason this agent stops pacing empty corridors.
    revisit_penalty: float = -2.0
    immediate_backtrack_penalty: float = -4.0


class PacManAgent:
    """A model-based, utility-based agent program."""

    percept_class = Percept

    def __init__(self, maze: MazeModel):
        self.maze = maze
        self.weights = UtilityWeights()
        self.last_reason = "Waiting for first percept."

        # Internal state: a compact summary of the percept sequence.
        self.visit_counts: dict[tuple[int, int], int] = {}
        self.position_history: deque[tuple[int, int]] = deque(maxlen=4)
        self.decision_count = 0
        self.revisit_decisions = 0
        self.backtrack_decisions = 0

    # -- internal state -------------------------------------------------

    def update_internal_state(self, percept: Percept) -> None:
        self.decision_count += 1
        self.visit_counts[percept.player] = self.visit_counts.get(percept.player, 0) + 1
        self.position_history.append(percept.player)

    # -- utility --------------------------------------------------------

    def evaluate_action(
        self,
        percept: Percept,
        action: tuple[int, int],
    ) -> tuple[float, dict[str, float]]:
        if action not in percept.legal_actions:
            raise ValueError(f"Cannot evaluate illegal action: {action}")

        landing = self.maze.step(percept.player, action)
        food = set(percept.pellets) | set(percept.power_pellets)
        ghosts = set(percept.released_ghosts)

        food_distance = self.maze.distance(landing, food)
        ghost_distance = self.maze.distance(landing, ghosts)

        contributions: dict[str, float] = {
            "food_distance": self.weights.food_distance * food_distance,
            "regular_pellet": (
                self.weights.regular_pellet if landing in percept.pellets else 0.0
            ),
            "power_pellet": (
                self.weights.power_pellet if landing in percept.power_pellets else 0.0
            ),
            "ghost": 0.0,
            "continuation": (
                self.weights.continuation
                if action == percept.current_direction
                else 0.0
            ),
            "revisit": 0.0,
            "backtrack": 0.0,
        }

        if percept.frightened:
            if landing in ghosts:
                contributions["ghost"] = self.weights.frightened_ghost_capture
            elif ghosts:
                contributions["ghost"] = (
                    self.weights.frightened_ghost_distance * ghost_distance
                )
        else:
            if landing in ghosts:
                contributions["ghost"] = self.weights.collision
            elif ghost_distance == 1:
                contributions["ghost"] = self.weights.ghost_one_step
            elif ghost_distance == 2:
                contributions["ghost"] = self.weights.ghost_two_steps
            elif ghost_distance == 3:
                contributions["ghost"] = self.weights.ghost_three_steps
            elif ghosts:
                contributions["ghost"] = self.weights.safe_ghost_distance * min(
                    ghost_distance, self.weights.safe_ghost_distance_cap
                )

        revisit_count = self.visit_counts.get(landing, 0)
        contributions["revisit"] = self.weights.revisit_penalty * revisit_count

        reversing = (
            len(self.position_history) >= 2 and landing == self.position_history[-2]
        )
        if reversing:
            contributions["backtrack"] = self.weights.immediate_backtrack_penalty

        total = sum(contributions.values())
        details = {
            **contributions,
            "food_distance_steps": float(food_distance),
            "ghost_distance_steps": float(ghost_distance),
            "revisit_count": float(revisit_count),
        }
        return total, details

    # -- selection ------------------------------------------------------

    def choose_action(self, percept: Percept) -> tuple[int, int]:
        if not percept.legal_actions:
            self.last_reason = "No legal move."
            return (0, 0)

        self.update_internal_state(percept)

        best_action = percept.legal_actions[0]
        best_utility = float("-inf")
        best_details: dict[str, float] = {}

        # Strictly-greater comparison over a fixed iteration order keeps
        # tie-breaking deterministic across runs and machines.
        for action in percept.legal_actions:
            utility, details = self.evaluate_action(percept, action)
            if utility > best_utility:
                best_utility = utility
                best_action = action
                best_details = details

        if best_details.get("revisit_count", 0.0) > 0.0:
            self.revisit_decisions += 1
        if best_details.get("backtrack", 0.0) < 0.0:
            self.backtrack_decisions += 1

        memory = best_details.get("revisit", 0.0) + best_details.get("backtrack", 0.0)
        self.last_reason = (
            f"{DIRECTION_NAMES[best_action]} | U={best_utility:.1f} | "
            f"food={int(best_details.get('food_distance_steps', 0.0))} | "
            f"ghost={int(best_details.get('ghost_distance_steps', 0.0))} | "
            f"memory={memory:.1f}"
        )

        return best_action
