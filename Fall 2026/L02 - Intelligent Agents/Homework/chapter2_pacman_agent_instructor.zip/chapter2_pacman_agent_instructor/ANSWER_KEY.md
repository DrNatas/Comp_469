# Answer Key - Chapter 2 Write-Up

Not for distribution.

Reference answers for `writeup/WRITEUP_TEMPLATE.md`. These are model
answers, not the only acceptable ones. Where a question has a genuine
argument on both sides, that is flagged, and students who take the other
side with a real justification should get full marks.

---

## 1. PEAS description (5 points)

**Performance measure.** `Simulation.performance()` in `pacman/rules.py`.
Terms: `+10` per pellet, `+50` per power pellet, `+200` per ghost eaten,
`+2000` for clearing the maze, `-1000` for being caught, `-0.20` per
decision, `-2.0` per immediate reversal. The last two are the ones students
overlook, and they are why an agent that survives by pacing still scores
badly.

**Environment.** A 17x10 grid maze with wrapping columns, 69 pellets, 4
power pellets, 3 ghosts released at 0/400/800 ms from a central house, and a
clock in which Pac-Man acts every 135 ms and ghosts every 135 ms on
`normal`. Ghosts chase with probability 0.80 and otherwise move randomly, and
they flee while frightened mode is active for 2 seconds after a power pellet.

**Actuators.** Exactly one of four moves per turn: left, right, up, down. An
illegal action is silently discarded and the agent stays put, which still
costs a decision. That last detail is worth a point on its own; students who
notice it usually also handle the empty-legal-actions case properly.

**Sensors.** Whatever the `Percept` dataclass declares.
`Simulation.sense()` reads the field names off the student's own dataclass
and fills exactly those from `Simulation.sensor_readings()`. The sensor
suite is therefore chosen by the agent designer, not fixed by the
environment. A student who says "the sensors are position, ghosts, and
pellets" without naming this mechanism gets partial credit.

## 2. Environment properties (7 points)

| Property | Answer | Justification |
|---|---|---|
| Observability | **Fully observable** for an agent that declares the right fields | `sensor_readings()` returns the complete pellet set and all released ghost positions with no noise, occlusion, or radius limit |
| Agents | **Multi-agent, adversarial** | ghosts minimise Manhattan distance to Pac-Man in `_choose_ghost_action` |
| Determinism | **Nondeterministic** | `self.rng.random() < self.chase_probability` means the same action in the same state can lead to different successors |
| Episodes | **Sequential** | eating a power pellet at turn 20 determines whether contact at turn 30 scores 200 or ends the game |
| Change | **Dynamic** | ghosts move on their own 135 ms schedule regardless of what the agent is computing |
| Values | **Discrete** | tile positions, four actions, integer millisecond ticks; pixel interpolation in `render.py` is display only and touches no rule |
| Knowledge | **Known** | the agent is handed a complete `MazeModel` at construction, so wall layout and distances need no learning |

**Follow-up.** The two defensible-both-ways answers:

*Observable.* A student can argue partial observability on the grounds that
the agent cannot see ghost *headings*, only positions, so it cannot
distinguish a ghost about to turn toward it from one about to turn away.
This is correct and a good answer. Accept it.

*Discrete vs continuous.* Time is arguably continuous, or at least the
interleaving of two different periods makes it feel so. Accept it if they
point at `advance()` and the two schedules rather than at the animation.

Do not accept "partially observable because Pac-Man cannot see through
walls." Nothing in the code implements line of sight.

## 3. Agent type (5 points)

**Figure.** Figure 2.12 (model-based reflex) combined with Figure 2.14
(utility-based). A student who says only Figure 2.14 is fine if they then
identify the internal state; the two are not cleanly separable here.

Box-by-box mapping:

| Figure 2.12 / 2.14 box | Code |
|---|---|
| Sensors | `Percept`, filled by `Simulation.sense()` |
| State | `visit_counts`, `position_history` |
| How the world evolves | `maze.step`, `maze.distance` |
| What my actions do | landing tile computed in `evaluate_action` |
| Utility | `UtilityWeights` applied in `evaluate_action` |
| Actuators | the single action returned by `choose_action` |

**Percept choice.** `released_ghosts` is correct. `ghosts` includes ghosts
still inside the house, which cannot reach Pac-Man, so an agent using it
will route around a threat that does not exist and lose points to the
per-decision cost. A student who chose `ghosts` and did not notice loses a
point here; one who chose it deliberately and explains the tradeoff does
not.

**One step further.** Two acceptable directions. A *goal-based* framing that
plans a route through remaining pellets rather than scoring one step at a
time, which is Chapter 3. Or a *learning agent* per Figure 2.15, with the
performance measure as the critic and the utility weights as what the
learning element adjusts. The second is stronger because it names the
critic; the first is more honest about where the course actually goes next.

## 4. Performance measure vs utility function (6 points)

**Locations.** Performance measure: `Simulation.performance()` in
`pacman/rules.py`. Utility function: `UtilityWeights` plus
`evaluate_action` in `agent.py`. Different files, and that separation is
deliberate.

**Where they disagree.** Several valid answers:

- The utility function rewards *proximity* to food (`food_distance`); the
  performance measure only pays for food actually eaten. Proximity is a
  proxy the agent can compute one step at a time.
- `continuation` has no counterpart in the performance measure at all. It
  exists to stop jitter, not to earn points.
- The performance measure charges `-0.20` per decision; nothing in the
  utility function represents time directly. The agent minimises time only
  as a side effect of chasing food.
- The reverse case: the performance measure pays `+200` for eating a ghost,
  and a student who set `frightened_ghost_capture` low is leaving points on
  the table on purpose, because chasing is risky.

**Why AIMA insists.** Full marks for an answer containing the idea that the
performance measure is imposed from outside by the designer and evaluates
behaviour in the environment, while utility is internal machinery the agent
uses to pick actions. The agent cannot compute the performance measure at
decision time, because it depends on how the episode ends. Conflating the
two leads to designing an agent that optimises the wrong thing, and to the
mistake of assuming an agent that "wants" the right thing will get it.

## 5. Rational is not the same as successful (4 points)

Any `hard` seed where the agent is caught works; the reference solution
loses about 85 percent of `hard` episodes, so students will not struggle to
find one.

A full-credit answer contains three things: a specific seed, a description
of the decision, and the observation that the agent's choice was optimal
*with respect to the percept it received*. The standard shape is that the
agent moved into a corridor with the nearest ghost three tiles away, which
its weights rate as acceptable, and the ghost then made a chase move rather
than a random one and closed the gap faster than the agent could clear the
corridor.

The key sentence, from AIMA 2.2.2: rationality maximises *expected*
performance given the percept sequence; omniscience would be required to
maximise *actual* performance. The agent could not have known which branch
the ghost's RNG would take, because that information is not in any percept
field the environment offers.

**What would make it irrational.** If the losing information *was* in the
percept and the agent ignored it. For example, if the agent walked into a
tile occupied by a visible dangerous ghost, that is irrational, and it is
exactly what the starter does.

Deduct for answers that say the agent was irrational because it lost, or
that blame randomness without connecting it to the percept.

## 6. Trial results (3 points)

Reference numbers, 60 seeds, `normal`:

| agent | win_rate | caught_rate | mean_score | mean_decisions | mean_backtracks | mean_performance |
|---|---|---|---|---|---|---|
| student (reference) | 0.967 | 0.017 | 1506 | 138 | 4.4 | 3385 |
| simple_reflex | 0.000 | 0.000 | 660 | 1500 | high | -218 |
| random | 0.000 | 1.000 | 200 | 66 | high | -861 |

A full-credit interpretation says something like: the gap to `random` is
produced by having condition-action rules at all; the gap from
`simple_reflex` to the finished agent is produced by internal state, and the
evidence is `mean_decisions` and `mean_backtracks` rather than `win_rate`,
because `simple_reflex` does not die, it simply never finishes. The
`caught_rate` of 0.000 for `simple_reflex` is the interesting number: an
agent can be perfectly safe and still score badly.

Deduct for restating the table in prose. Deduct for attributing the
improvement to "better code" without naming an agent structure.
