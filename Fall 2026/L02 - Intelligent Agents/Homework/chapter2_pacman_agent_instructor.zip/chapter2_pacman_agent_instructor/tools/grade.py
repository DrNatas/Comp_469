#!/usr/bin/env python3
"""Grade Chapter 2 submissions.

INSTRUCTOR TOOL. Not distributed to students.

Each submission is either a zip or a folder containing `agent.py`. For every
one, this script rebuilds a pristine copy of the assignment package, drops
in the student's `agent.py` and nothing else, runs the contract tests and a
block of trials in a sandboxed subprocess with a timeout, and writes a CSV.

    python tools/grade.py --submissions ./submissions --output grades.csv

Add --verbose to see each failing test name as it goes.

Only the automated portion is scored here: 54 points of the agent program
and 10 points of trials, 64 total. Code quality (6) and the write-up (30)
are read by hand.
"""

from __future__ import annotations

import argparse
import csv
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from typing import Any

# Test-name prefix -> (label, points). Points inside a group are split
# evenly across the tests in it, so partial work earns partial credit.
GROUPS: list[tuple[str, str, float]] = [
    ("test_ch2_1_", "ch2_1_percept", 7.0),
    ("test_ch2_2_", "ch2_2_weights", 7.0),
    ("test_ch2_3_", "ch2_3_4_state", 4.5),
    ("test_ch2_4_", "ch2_3_4_state", 4.5),
    ("test_ch2_5_", "ch2_5_utility", 15.0),
    ("test_ch2_6_", "ch2_6_selection", 7.0),
    ("test_ch2_7_", "ch2_7_reason", 4.0),
    ("test_scope_", "scope_integrity", 5.0),
]

# Tests in tests/test_chapter2_performance.py are deliberately absent from
# GROUPS: they are scored from the trial numbers below, not twice.

TRIAL_SEEDS = 30
WIN_RATE_TARGET = 0.60
POINTS_TRIALS_WIN = 4.0
POINTS_TRIALS_BASELINE = 2.0
POINTS_TRIALS_FILES = 4.0

DEFAULT_TIMEOUT = 180


# ---------------------------------------------------------------------
# Sandboxed run, executed inside a rebuilt copy of the package
# ---------------------------------------------------------------------


def run_single(package_root: Path) -> dict[str, Any]:
    """Run tests and trials for one submission. Prints JSON to stdout."""
    import io
    import os

    os.chdir(package_root)
    sys.path.insert(0, str(package_root))

    result: dict[str, Any] = {"tests": {}, "trials": {}, "error": None}

    loader = unittest.TestLoader()
    suite = loader.discover(str(package_root / "tests"), pattern="test_*.py")

    # Collect names BEFORE running: unittest drops references to finished
    # tests as it goes, so walking afterwards yields None entries.
    all_tests: list[str] = []

    def walk(item):
        if isinstance(item, unittest.TestSuite):
            for child in item:
                walk(child)
        elif item is not None:
            all_tests.append(item.id().rsplit(".", 1)[-1])

    walk(suite)

    outcome = unittest.TextTestRunner(stream=io.StringIO(), verbosity=0).run(suite)

    failed = {
        test.id().rsplit(".", 1)[-1]
        for test, _ in list(outcome.failures) + list(outcome.errors)
    }
    result["tests"] = {name: (name not in failed) for name in all_tests}

    try:
        from pacman.headless import run_trials, summarize
        from pacman.registry import resolve_agents

        agents = resolve_agents(
            ["student", "simple_reflex"], package_root / "agent.py"
        )
        rows = run_trials(
            agents, list(range(1, TRIAL_SEEDS + 1)), difficulty="normal"
        )
        summary = {row["agent"]: row for row in summarize(rows)}
        result["trials"] = {
            "win_rate": summary["student"]["win_rate"],
            "mean_performance": summary["student"]["mean_performance"],
            "baseline_performance": summary["simple_reflex"]["mean_performance"],
            "mean_decisions": summary["student"]["mean_decisions"],
            "mean_backtracks": summary["student"]["mean_backtracks"],
        }
    except Exception as error:  # noqa: BLE001 - report, do not crash the batch
        result["error"] = f"{type(error).__name__}: {error}"

    return result


# ---------------------------------------------------------------------
# Batch driver
# ---------------------------------------------------------------------


def find_agent_file(submission: Path, workdir: Path) -> Path | None:
    if submission.is_dir():
        candidates = sorted(submission.rglob("agent.py"))
        return candidates[0] if candidates else None

    if submission.suffix.lower() == ".zip":
        extracted = workdir / "extracted"
        extracted.mkdir(parents=True, exist_ok=True)
        try:
            with zipfile.ZipFile(submission) as archive:
                archive.extractall(extracted)
        except zipfile.BadZipFile:
            return None
        candidates = sorted(extracted.rglob("agent.py"))
        return candidates[0] if candidates else None

    return None


def has_result_files(submission: Path, workdir: Path) -> bool:
    root = submission if submission.is_dir() else workdir / "extracted"
    if not root.exists():
        return False
    names = {path.name.lower() for path in root.rglob("*.csv")}
    return "trials.csv" in names and "summary.csv" in names


def build_sandbox(pristine: Path, agent_file: Path, workdir: Path) -> Path:
    sandbox = workdir / "package"
    shutil.copytree(
        pristine,
        sandbox,
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".venv", "results"),
    )
    (sandbox / "results").mkdir(exist_ok=True)
    shutil.copy2(agent_file, sandbox / "agent.py")
    return sandbox


def score(result: dict[str, Any], results_present: bool) -> dict[str, Any]:
    tests: dict[str, bool] = result.get("tests", {})
    group_points: dict[str, float] = {}
    group_totals: dict[str, float] = {}

    for prefix, label, points in GROUPS:
        members = [name for name in tests if name.startswith(prefix)]
        group_totals[label] = group_totals.get(label, 0.0) + points
        if not members:
            group_points.setdefault(label, 0.0)
            continue
        passed = sum(1 for name in members if tests[name])
        group_points[label] = group_points.get(label, 0.0) + points * passed / len(
            members
        )

    trials = result.get("trials") or {}
    win_rate = trials.get("win_rate")
    trial_points = 0.0
    if results_present:
        trial_points += POINTS_TRIALS_FILES
    if win_rate is not None and win_rate >= WIN_RATE_TARGET:
        trial_points += POINTS_TRIALS_WIN
    if (
        trials.get("mean_performance") is not None
        and trials.get("baseline_performance") is not None
        and trials["mean_performance"] > trials["baseline_performance"]
    ):
        trial_points += POINTS_TRIALS_BASELINE

    agent_points = round(sum(group_points.values()), 2)
    return {
        **{label: round(value, 2) for label, value in group_points.items()},
        "agent_points_54": agent_points,
        "trial_points_10": round(trial_points, 2),
        "auto_total_64": round(agent_points + trial_points, 2),
        "win_rate": win_rate if win_rate is not None else "",
        "mean_performance": trials.get("mean_performance", ""),
        "mean_decisions": trials.get("mean_decisions", ""),
        "mean_backtracks": trials.get("mean_backtracks", ""),
        "failed_tests": ";".join(
            sorted(name for name, ok in tests.items() if not ok)
        ),
        "error": result.get("error") or "",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Grade Chapter 2 submissions.")
    parser.add_argument("--submissions", type=Path)
    parser.add_argument("--output", type=Path, default=Path("grades.csv"))
    parser.add_argument("--pristine", type=Path, default=None)
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT)
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--single", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()

    if args.single is not None:
        print(json.dumps(run_single(args.single.resolve())))
        return

    if args.submissions is None:
        parser.error("--submissions is required")

    pristine = args.pristine or Path(__file__).resolve().parents[1]
    submissions = sorted(
        path
        for path in args.submissions.iterdir()
        if path.is_dir() or path.suffix.lower() == ".zip"
    )
    if not submissions:
        parser.error(f"No submissions found in {args.submissions}")

    rows: list[dict[str, Any]] = []

    for submission in submissions:
        name = submission.stem
        print(f"grading {name} ... ", end="", flush=True)

        with tempfile.TemporaryDirectory() as tmp:
            workdir = Path(tmp)
            agent_file = find_agent_file(submission, workdir)

            if agent_file is None:
                rows.append(
                    {"submission": name, "error": "no agent.py found", "auto_total_64": 0}
                )
                print("no agent.py")
                continue

            sandbox = build_sandbox(pristine, agent_file, workdir)
            results_present = has_result_files(submission, workdir)

            try:
                completed = subprocess.run(
                    [sys.executable, str(Path(__file__).resolve()),
                     "--single", str(sandbox)],
                    capture_output=True,
                    text=True,
                    timeout=args.timeout,
                )
                payload = json.loads(completed.stdout.strip().splitlines()[-1])
            except subprocess.TimeoutExpired:
                payload = {"tests": {}, "trials": {}, "error": "timeout"}
            except (json.JSONDecodeError, IndexError):
                payload = {
                    "tests": {},
                    "trials": {},
                    "error": f"harness failure: {completed.stderr[-300:]}",
                }

            row = {"submission": name, **score(payload, results_present)}
            rows.append(row)
            print(f"{row['auto_total_64']}/64")
            if args.verbose and row.get("failed_tests"):
                for failed in row["failed_tests"].split(";"):
                    print(f"    FAIL {failed}")

    columns = ["submission"] + [
        key for key in rows[0] if key != "submission"
    ] if rows else ["submission"]
    for row in rows:
        for key in row:
            if key not in columns:
                columns.append(key)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in columns})

    print(f"\nwrote {args.output}")


if __name__ == "__main__":
    main()
