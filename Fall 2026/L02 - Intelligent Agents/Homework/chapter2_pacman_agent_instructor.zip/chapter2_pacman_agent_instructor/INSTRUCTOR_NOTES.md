# Instructor Notes - Chapter 2 Pac-Man Agent

Not for distribution.

## What is in this package

This is the student package plus four instructor-only additions. To produce
the student handout, delete these and reset `agent.py` to the starter:

| Path | |
|---|---|
| `INSTRUCTOR_NOTES.md` | this file |
| `ANSWER_KEY.md` | model answers for the write-up |
| `solution/agent.py` | complete reference implementation |
| `tools/grade.py` | batch grader |

`agent.py` at the root is the **starter** in both packages, so you can run
`python tools/play.py` and show the broken agent without swapping files. To
demo the finished agent, copy `solution/agent.py` over it.

---

## What this assignment is for

AIMA Chapter 2 has one structural argument running through it: agent types
form a ladder, and each rung exists because the rung below it fails at
something specific. Most course materials present the ladder as a list of
figures. This assignment makes students climb it and feel the failures.

The environment is tuned so that the ladder is visible in the numbers rather
than asserted in a slide. Over 60 seeds on `normal`:

| Agent | Win rate | Mean performance | Mean decisions | Failure mode |
|---|---|---|---|---|
| `random` | 0.00 | -861 | 66 | eaten almost immediately |
| `simple_reflex` (provided) | 0.00 | -218 | 1500 (cap) | never dies, never finishes |
| starter `agent.py` (ghost-blind) | 0.00 | -434 | 58 | walks into ghosts |
| reference solution | 0.97 | +3385 | 138 | occasional bad luck |

Those four rows are the lecture. The `simple_reflex` row is the most useful
one: it survives and still scores badly, because with no internal state it
cannot tell an eaten corridor from a full one and paces until the decision
cap. That is exactly why Figure 2.11 exists.

## Calibration, and why the environment is what it is

The original version of this demo had a flaw worth knowing about, because a
student may rediscover it. Power pellets sat in all four corners, directly on
the corridor a greedy food-seeker walks first, and frightened mode lasted
seven seconds out of a roughly twelve-second episode. The result was that a
ghost-blind agent was invulnerable for most of the game and won 100 percent
of episodes, while a ghost-aware agent that chased frightened ghosts got
itself killed. The environment rewarded ignoring ghosts, which inverts the
entire assignment.

Three changes fixed it, and none of them should be altered casually:

1. Power pellets moved off the main corridors into the vertical pockets at
   `(2,5)`, `(2,13)`, `(6,1)`, `(6,15)`. Eating one is now a decision, not
   something that happens on the way past.
2. `POWER_DURATION_MS` dropped from 7000 to 2000.
3. Ghosts released at 0/400/800 ms instead of 1200/3000/5200, and moved at
   the player's speed rather than slower.

If you edit the maze, rerun the calibration table above before assigning it.
The check that matters is that the **starter** loses and the **solution**
wins; a change that raises both is not a difficulty change.

## Difficulty settings

`normal` is what students are graded on: ghosts move at exactly Pac-Man's
speed. `hard` makes them faster, which is the one difficulty knob that
behaves monotonically here. Reference solution on `hard`: 0.12 win rate, 0.85
caught. That is deliberate, and Part 3 question 5 depends on it.

Do not be tempted to tune `hard` toward a middling win rate by adjusting
chase probability. Ghost period and player period interact through tick
alignment, and the results are not monotonic in either parameter. I swept it;
0.85 chase at 120 ms produced 85 percent timeouts rather than deaths, which
is a worse teaching artifact than a clean loss.

## A 20-minute lecture demo

1. Run `python tools/play.py --agent random`. Twenty seconds. Establish the
   floor.
2. Run `python tools/play.py --agent simple_reflex`. Let it run past the
   point where it clears the easy pellets. Ask the room why it is pacing.
   Someone will say it forgot. That word is the whole lesson; write
   "internal state" on the board.
3. Open `pacman/agents/simple_reflex.py`. It is about 50 lines of
   condition-action rules. Map it onto Figure 2.10 line by line.
4. Run `python tools/play.py` with the reference solution in place and point
   at the status bar. Every turn prints
   `LEFT | U=-31.0 | food=3 | ghost=6 | memory=-2.0`. Pause on a turn where
   the agent turns away from nearby food and ask why. The answer is in the
   line.
5. Run `python tools/run_trials.py`. Show the table. Ask which column proves
   memory helped, and make them find `mean_decisions` and
   `mean_backtracks` rather than `win_rate`.

If you have time, delete the two memory weights from the solution
(`revisit_penalty` and `immediate_backtrack_penalty` to `0.0`) and rerun
trials live. Win rate falls from 0.97 to 0.85, decisions rise from 138 to
310, and backtracks go from 4 to 113. That single edit is the most
persuasive thing in the whole unit.

## Common student failure modes

**Percept declares `ghosts` instead of `released_ghosts`.** Everything still
runs, but the agent flees from ghosts locked in the house and wastes moves.
Tests pass. Catch it in the write-up, where question 3 asks about exactly
this choice.

**Utility weights defined but literals left in `evaluate_action`.** The test
`test_ch2_2_weights_are_actually_used` overrides the collision weight and
checks behaviour changes, so this fails. Students often do not understand
why; the message names the cause.

**`position_history` used as a full log.** Works, but the revisit term then
double-counts with `visit_counts` and the agent becomes strangely
claustrophobic. `test_ch2_4_position_history_is_bounded` catches it.

**`update_internal_state` called inside `evaluate_action`.** Memory then
updates once per legal action instead of once per turn, so visit counts
inflate by a factor of two to four and the agent avoids everything.
`test_ch2_6_choose_action_updates_memory_once_per_turn` catches it.

**Reimplementing BFS.** Usually a strong student who has read ahead. The
scope test catches it, but talk to them rather than just deducting; they are
ready for Chapter 3 and this is a good conversation.

**Ghost weights too timid.** The single most common cause of a win rate
between 0.3 and 0.6. The reference uses -800 / -400 / -150 for one, two, and
three steps. Students who start at -300 / -100 / -30 die a lot. Do not give
this away; the write-up asks them to defend their numbers, and tuning them is
the point.

## Grading

```
python tools/grade.py --submissions ./submissions --output grades.csv --verbose
```

Accepts zips or folders. For each one it rebuilds a pristine copy of the
package, drops in only the student's `agent.py`, and runs the tests and 30
trials in a subprocess with a 180-second timeout. A student who edits
`pacman/` therefore gets graded against the original, which is the stated
policy in `ASSIGNMENT.md`.

Output is 64 automated points: 54 for the agent program, split within each
test group so partial work earns partial credit, and 10 for trials. The
remaining 36 are manual: 6 for code quality, 30 for the write-up.

Verified behaviour: reference solution scores 64/64; the unmodified starter
scores 11.92/64, with partial credit on CH2-1 and CH2-6 because the starter
does declare some percept fields and does handle the empty-action case.

Timeouts are recorded rather than crashing the batch, so a student with an
infinite loop still produces a row.

## Time estimate

Students who have read the chapter: three to five hours for the code, one to
two for the write-up. The long pole is weight tuning, which is intentional.
CH2-5 is the only task that regularly takes more than an hour.

## Things I would change next time

The `simple_reflex` baseline hits the 1500-decision cap on every seed, so its
`mean_decisions` is a censored value rather than a real one. It makes the
point fine, but if you want an honest number, raise the cap for that agent
only, or report time-to-cap instead.
