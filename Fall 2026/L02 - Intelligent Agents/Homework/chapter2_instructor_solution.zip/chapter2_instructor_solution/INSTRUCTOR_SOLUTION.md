# Instructor Solution and Answer Key

## 1. Agent and environment

**Agent.** Pac-Man, represented by `PacManAgent` as the decision-making program and `PacMan` as the movable game entity.

**Environment.** The maze, walls, regular pellets, power pellets, released and unreleased ghosts, frightened timer, score, movement timing, collision rules, and terminal win/loss states maintained by `Game`.

**Sensors.** `Game.sense_environment()` constructs a `Percept`. In the solution it supplies Pac-Man's position and direction, remaining pellets and power pellets, released ghost positions, legal actions, and frightened time remaining.

**Actuators.** The four movement tuples in `DIRECTIONS`; `(0, 0)` is used only when no legal movement exists.

**Percept.** One immutable `Percept` instance at the current decision time.

**Percept sequence.** The full history of those percepts. The program does not store every percept; it stores compact summaries in `visit_counts` and `position_history`.

**Agent function.** The abstract mapping from every possible percept sequence to an action. It is not identical to one Python method.

**Agent program.** The concrete Python code in `PacManAgent`, especially `update_internal_state`, `evaluate_action`, and `choose_action`.

**Architecture.** The Python interpreter, memory, processor, Pygame game loop, display/input interfaces, and the `Game` methods that connect percepts and movement actions.

## 2. Rationality and performance measure

A defensible external performance measure for this lab is:

1. Reward clearing the maze with a large completion bonus.
2. Penalize being caught heavily.
3. Add the game's final score.
4. Prefer fewer decisions when completion and safety are otherwise comparable.
5. Penalize immediate backtracking because it is evidence of unnecessary repeated movement.

The headless support tool operationalizes that example as:

`2000 * win + score - 1000 * caught - 0.20 * decisions - 2 * immediate_backtracks`.

This measure evaluates consequences in the environment, not whether the program executed its own code correctly. A bad proxy would reward only pellets eaten: an agent could repeatedly take reckless paths, earn some pellet points, and be caught without ever completing the maze.

Rationality depends on the performance measure, prior knowledge, available actions, and percept sequence. The baseline has prior knowledge of maze geometry and movement rules; it can choose only legal grid movements; it receives current Pac-Man/pellet information; and it obtains some dynamic facts through hidden `self.game` access rather than through the percept. It can be locally rational relative to its limited one-step utility model while still losing. A stochastic ghost choice can cause an unfavorable result even after a reasonable action, so rationality is not omniscience, perfection, or guaranteed success.

## 3. PEAS

| Element | Solution |
|---|---|
| Performance | Clear all pellets, survive, earn score, finish with fewer decisions, avoid unnecessary backtracking, and exploit power mode without reckless collisions. |
| Environment | Grid maze, walls, wrap corridor, regular pellets, power pellets, ghosts and ghost house, release and frightened timers, score, collision rules, and win/loss states. |
| Actuators | Legal movement actions Left, Right, Up, and Down; Stop only when no legal move exists. |
| Sensors | Current position and direction, remaining pellet sets, released ghost positions, legal actions, and frightened time remaining. |

## 4. Task-environment classification

| Dimension | Classification and evidence |
|---|---|
| Observability | **Effectively fully observable for the represented decision variables after the refactor**, because the percept exposes all dynamic facts used by the policy. It is still a simplified sensor model; richer hidden ghost intentions or future random choices would make it partially observable. |
| Agents | **Multiagent** when ghosts are treated as goal-directed entities whose behavior depends on Pac-Man. Their objectives partly conflict with Pac-Man's. |
| Transition | **Stochastic**, because the ghost policy explicitly uses random choices and probabilities. The program's rules are known, but one action can lead to different subsequent states. |
| Episodes | **Sequential**, because each move changes later positions, remaining pellets, risk, and available actions. |
| Time | **Dynamic**, because ghosts and timers change while play continues. |
| State/action | **Discrete at the agent level**, because grid cells and movement commands are discrete, even though rendering interpolates continuous pixel positions. |
| Knowledge | **Known with respect to the supplied rules and maze**, because the program contains the transition rules and static map. Particular future random ghost choices are unknown, which is uncertainty rather than an unknown rule set. |

## 5. Starter-agent audit

| Information | Baseline source | Category |
|---|---|---|
| Pac-Man position | `percept.player` | Percept |
| Legal actions | `percept.legal_actions` | Percept |
| Pellet locations | `percept.pellets` | Percept |
| Power-pellet locations | `percept.power_pellets` | Percept |
| Released ghost positions | `self.game.ghosts` plus each `released` flag | Hidden dynamic environment access |
| Frightened mode | `self.game.ghosts_are_frightened()` | Hidden dynamic environment access |
| Current direction | `self.game.player.direction` | Hidden dynamic environment access |
| Walls and wrapping | `self.game.is_wall`, `is_ghost_door`, and `wrap_col` | Built-in static prior knowledge |

## 6. Agent-type classification

The baseline is not a pure simple reflex agent because it numerically compares candidate consequences and uses remaining pellets as desirable targets. It has a **utility-based component** because it chooses the legal action with greatest calculated utility, and a limited **goal-based component** because remaining pellets represent desirable target situations. It does not maintain internal state derived from percept history and it does not learn from feedback.

The solution is a **mixed model-based utility agent**. Its visit counts and short position history are internal state derived from the percept sequence. Its utility function explicitly trades food progress, immediate rewards, ghost risk/opportunity, continuation, revisiting, and immediate backtracking. It still does not learn: weights and update rules remain fixed during a run.

## 7. Why the code changes satisfy Chapter 2

- `Percept` now defines the sensor boundary explicitly.
- `sense_environment()` supplies current dynamic information.
- `visit_counts` and `position_history` summarize relevant percept history.
- `UtilityWeights` makes the internal desirability model inspectable.
- `evaluate_action()` represents tradeoffs; `choose_action()` selects the greatest-utility legal action.
- `last_reason` exposes program evidence but does not replace external evaluation.

The maze-distance helper remains fixed infrastructure. The assignment does not ask students to implement or compare search algorithms.

## 8. Representations

The implemented percept is **factored** because a situation is divided into named attributes with values: position, direction, pellet sets, ghost positions, legal actions, and frightened time.

An **atomic** alternative could assign one opaque label such as `STATE_18427` to the entire situation, with no accessible internal fields.

A **structured** alternative could represent explicit objects and relations: `Ghost(g1)`, `Frightened(g1)`, and `Distance(g1, PacMan, 2)`.

More expressive representations make relationships easier to state and reuse, but they generally increase the complexity of inference and implementation.

## 9. Learning-agent extension

| Component | Pac-Man interpretation |
|---|---|
| Performance element | `evaluate_action()` and `choose_action()`, which score legal actions and return movement. |
| Learning element | A proposed component that adjusts ghost-risk, power-pellet, or revisit weights from completed trials. |
| Critic | A component that computes feedback from the fixed performance measure using win/loss, score, decisions, and backtracking. |
| Problem generator | A component that occasionally tries a near-tied legal action or a less-used corridor to gather informative experience. |

For example, the learning element could increase the one-step ghost penalty after repeated caught outcomes near ghosts. Improvement would be supported by higher paired-seed performance under the fixed external measure, not merely by the weight changing.

## 10. Experimental results

The included `results/trials.csv` and `results/summary.csv` are generated by the pure-Python support runner using paired seeds. These numbers are evidence for this implementation and runner, not universal claims about all Pygame executions.

| Agent | Trials | Win rate | Average score | Average decisions | Average immediate backtracks | Average performance |
|---|---:|---:|---:|---:|---:|---:|
| Baseline | 20 | 100% | 2040.0 | 139.0 | 6.0 | 4000.2 |
| Modified | 20 | 100% | 2040.0 | 139.0 | 3.0 | 4006.2 |

Under the stated measure, the modified agent performs slightly better because it preserves the same completion rate, score, and decision count while reducing immediate backtracking by half. The conclusion is deliberately narrow: all 20 seeds produced the same outcome in this small maze, so the trial set did not expose meaningful stochastic variation. The strongest supported claim is that the memory term changed repeated-movement behavior without harming the other recorded criteria in this support simulation.


## 11. Conclusion and limitations

The solution creates a clearer agent/environment boundary and demonstrates that a compact memory of percept history can alter current action selection. In the paired sample, the appropriate conclusion depends on the complete performance measure: reduced backtracking is beneficial only if it does not substantially reduce completion, safety, or score.

Limitations include the small maze, handcrafted utility weights, a short trial set, and the headless runner's discrete collision approximation. The agent also treats maze geometry as known prior knowledge and does not learn. Therefore, results support a narrow comparison of these two programs under stated assumptions; they do not establish a generally optimal Pac-Man policy.
