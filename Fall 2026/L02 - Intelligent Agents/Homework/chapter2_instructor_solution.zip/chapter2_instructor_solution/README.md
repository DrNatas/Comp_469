# Chapter 2 Intelligent Agents - Instructor Solution Package

This package contains the untouched baseline, a complete Chapter 2 solution,
contract tests, a headless paired-trial runner, sample results, and the written
answer key.

## Validate the code

```bash
python -m py_compile src/autonomous_pacman_agent_baseline.py
python -m py_compile src/autonomous_pacman_agent.py
python -m unittest discover -s tests -v
```

The tests use a small import stub and therefore do not need Pygame. Interactive
play does require Pygame:

```bash
python -m pip install pygame
python src/autonomous_pacman_agent.py
```

## Reproduce the sample comparison

```bash
python tools/run_trials.py \
  --baseline src/autonomous_pacman_agent_baseline.py \
  --modified src/autonomous_pacman_agent.py \
  --count 20 \
  --output results/trials.csv \
  --summary results/summary.csv
```

The headless runner is evaluation support, not a new AI topic. The supplied
maze-distance helper is also treated as fixed infrastructure; students are not
asked to implement or analyze formal search algorithms.
