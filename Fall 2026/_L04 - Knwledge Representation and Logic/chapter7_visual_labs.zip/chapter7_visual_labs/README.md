# Chapter 7 Visual Labs: Logical Agents

These five standalone Jupyter notebooks teach Chapter 7 topics with executable code and graphics.

1. **Lab 07A** - Knowledge-based agents and Wumpus World logical state estimation.
2. **Lab 07B** - Propositional logic syntax, semantics, truth tables, and model checking.
3. **Lab 07C** - CNF conversion, theorem proving, and resolution proof graphs.
4. **Lab 07D** - Horn clauses, forward chaining, backward chaining, and AND-OR proof views.
5. **Lab 07E** - DPLL, WalkSAT, SATPLAN, and propositional-logic scaling limits.

## Student setup

Install Jupyter and the two required packages if needed:

```bash
pip install jupyter matplotlib ipywidgets
```

Then open the notebooks with:

```bash
jupyter notebook
```

Each notebook is standalone; students do not need to import code from another lab.
